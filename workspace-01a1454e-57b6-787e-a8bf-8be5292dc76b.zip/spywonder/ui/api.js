/* One transport boundary. Views know only request(operation, validated arguments). */
window.SpyAPI = (() => {
  let bridge, sequence = 0;
  const pending = new Map();
  const ready = new Promise(resolve => {
    window.addEventListener('DOMContentLoaded', () => {
      if (window.qt && window.QWebChannel) {
        new QWebChannel(qt.webChannelTransport, channel => {
          bridge = channel.objects.backend;
          bridge.reply.connect((id, payload) => {
            const item = pending.get(id);
            if (item) { clearTimeout(item.timer); pending.delete(id); item.resolve(JSON.parse(payload)); }
          });
          resolve();
        });
      } else resolve();
    });
  });
  async function request(op, args = {}) {
    await ready;
    let envelope;
    if (bridge) {
      envelope = await new Promise((resolve, reject) => {
        const id = String(++sequence);
        const timer = setTimeout(() => { pending.delete(id); reject(new Error('Backend response timed out')); }, 125000);
        pending.set(id, {resolve, timer});
        bridge.request(id, JSON.stringify({op, args}));
      });
    } else {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 15000);
      try {
        const response = await fetch('/api', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({op, args}), signal: controller.signal});
        if (!response.ok) throw new Error(`Backend HTTP ${response.status}`);
        envelope = await response.json();
      } finally { clearTimeout(timer); }
    }
    if (!envelope.ok) throw new Error(`${envelope.error.code}: ${envelope.error.message}`);
    return envelope.data;
  }
  return {request};
})();
