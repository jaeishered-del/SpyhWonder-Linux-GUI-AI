"""Native Qt 6 host. Run as a regular desktop user, never with sudo."""
import argparse
import json
import os
import sys
from pathlib import Path

def main():
    if os.geteuid() == 0: raise SystemExit('Refusing to run the GUI as root. Use a regular desktop session.')
    from PySide6.QtCore import QObject, Signal, Slot, QUrl, QRunnable, QThreadPool, Qt
    from PySide6.QtWidgets import QApplication, QMainWindow
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineUrlRequestInterceptor, QWebEngineSettings
    from PySide6.QtWebChannel import QWebChannel
    from backend.service import create_backend, handle
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli-config', help='Explicit opt-in CLI adapter JSON config')
    parser.add_argument('--smoke-test', action='store_true', help='Exit after the page loads')
    options = parser.parse_args()
    backend = create_backend(options.cli_config)
    app = QApplication(sys.argv[:1])
    app.setApplicationName('SpyWonder OS')

    class Worker(QRunnable):
        def __init__(self, bridge, request_id, payload):
            super().__init__(); self.bridge, self.request_id, self.payload = bridge, request_id, payload
        def run(self):
            result = handle(backend, self.payload)
            self.bridge.reply.emit(self.request_id, json.dumps(result))

    class Bridge(QObject):
        reply = Signal(str, str)
        @Slot(str, str)
        def request(self, request_id, payload):
            try:
                if len(payload) > 8192: raise ValueError()
                request = json.loads(payload)
            except ValueError:
                self.reply.emit(request_id, json.dumps({'ok': False, 'error': {'code': 'INVALID_REQUEST', 'message': 'Invalid JSON'}})); return
            pool.start(Worker(self, request_id, request))

    class LocalOnly(QWebEngineUrlRequestInterceptor):
        def interceptRequest(self, info):
            if info.requestUrl().scheme() not in ('file', 'qrc', 'data'): info.block(True)

    class Page(QWebEnginePage):
        def acceptNavigationRequest(self, url, kind, main_frame):
            return url.toLocalFile() == str(Path(__file__).parent / 'ui' / 'index.html') or url.scheme() == 'qrc'

    window = QMainWindow()
    window.setWindowTitle('SpyWonder OS · Desktop prototype')
    window.resize(1480, 960)
    view = QWebEngineView(window)
    page = Page(view)
    view.setPage(page)
    interceptor = LocalOnly(page)
    page.profile().setUrlRequestInterceptor(interceptor)
    page.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
    channel = QWebChannel(page)
    bridge = Bridge(channel)
    pool = QThreadPool(bridge)
    pool.setMaxThreadCount(1)
    channel.registerObject('backend', bridge)
    page.setWebChannel(channel)
    window.setCentralWidget(view)
    view.load(QUrl.fromLocalFile(str(Path(__file__).parent / 'ui' / 'index.html')))
    window.show()
    if options.smoke_test:
        from PySide6.QtCore import QTimer
        def check():
            page.runJavaScript("document.body.dataset.ready === 'true'", lambda ready: app.exit(0 if ready else 2))
        QTimer.singleShot(5000, check)
    code = app.exec()
    pool.waitForDone()
    return code

if __name__ == '__main__': sys.exit(main())
