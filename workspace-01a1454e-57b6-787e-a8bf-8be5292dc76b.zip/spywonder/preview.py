"""Browser preview: mock backend only. No system adapter exposed over HTTP."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse
import json
import os
from backend.mock import MockBackend
from backend.service import handle

backend = MockBackend()
ROOT = Path(__file__).parent / 'ui'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(ROOT), **kwargs)
    def do_POST(self):
        if self.path != '/api': self.send_error(404); return
        try:
            # No CORS; only JSON same-origin requests. This endpoint can mutate mock state only.
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 8192 or self.headers.get_content_type() != 'application/json': self.send_error(400); return
            response = handle(backend, json.loads(self.rfile.read(size)))
        except (ValueError, UnicodeError): self.send_error(400); return
        payload = json.dumps(response).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers(); self.wfile.write(payload)
    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()

if __name__ == '__main__':
    if os.geteuid() == 0: raise SystemExit('Run as a regular user, not root')
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5173)
    parser.add_argument('--host', default='127.0.0.1')
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f'SpyWonder mock preview on {args.host}:{args.port}', flush=True)
    server.serve_forever()
