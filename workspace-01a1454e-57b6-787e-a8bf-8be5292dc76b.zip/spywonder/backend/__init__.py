"""Backend boundary: UI code never invokes system commands directly."""
