"""Opt-in CLI adapter. Never uses a shell, stdin commands, sudo, or UI paths."""
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import tempfile
from .contracts import BackendError, argv_for

MAX_OUTPUT = 1024 * 1024

class CLIBackend:
    mode = 'cli'
    def __init__(self, config_path):
        cfg = json.loads(Path(config_path).read_text())
        if set(cfg) - {'executable', 'timeout_seconds', 'allow_mutations'}:
            raise ValueError('Unknown adapter configuration key')
        path = Path(cfg['executable'])
        if not path.is_absolute(): raise ValueError('Executable must be an absolute path')
        self.path = path.resolve(strict=True)
        info = self.path.stat()
        if not stat.S_ISREG(info.st_mode) or not os.access(self.path, os.X_OK):
            raise ValueError('Executable must be an executable regular file')
        if info.st_mode & (stat.S_IWGRP | stat.S_IWOTH): raise ValueError('Executable must not be group/world writable')
        if info.st_uid not in (0, os.getuid()): raise ValueError('Executable owner is not trusted')
        for parent in self.path.parents:
            if parent.stat().st_mode & (stat.S_IWGRP | stat.S_IWOTH):
                raise ValueError('Executable ancestors must not be group/world writable')
        self.timeout = cfg.get('timeout_seconds', 15)
        if type(self.timeout) not in (int, float) or not 1 <= self.timeout <= 120: raise ValueError('Timeout must be 1–120 seconds')
        self.allow_mutations = cfg.get('allow_mutations', False)
        if type(self.allow_mutations) is not bool: raise ValueError('allow_mutations must be boolean')

    def request(self, op, args):
        argv = [str(self.path), *argv_for(op, args)]
        if op not in ('snapshot', 'metrics', 'updates.check') and not self.allow_mutations:
            raise BackendError('READ_ONLY', 'CLI mutations are disabled in adapter configuration')
        env = {'PATH': '/usr/bin:/bin', 'HOME': str(Path.home()), 'LANG': 'C.UTF-8'}
        # Disk-backed capture avoids unbounded output allocation. CLI remains a trusted local executable.
        with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
            try:
                process = subprocess.Popen(argv, shell=False, stdin=subprocess.DEVNULL, stdout=out, stderr=err, env=env, cwd=str(Path.home()), start_new_session=True)
                try: process.wait(timeout=self.timeout)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                    raise BackendError('TIMEOUT', 'CLI timed out; its process group was stopped')
            except OSError as exc:
                raise BackendError('UNAVAILABLE', 'CLI could not be started') from exc
            if process.returncode: raise BackendError('CLI_FAILED', f'CLI exited with status {process.returncode}; inspect CLI logs locally')
            if out.tell() > MAX_OUTPUT: raise BackendError('INVALID_RESPONSE', 'CLI response exceeds 1 MiB')
            out.seek(0)
            try:
                response = json.loads(out.read())
                if not isinstance(response, dict) or type(response.get('ok')) is not bool: raise ValueError()
                if response['ok']:
                    data = response['data']
                    if not isinstance(data, dict): raise ValueError()
                    if op != 'metrics':
                        required = {'system', 'settings', 'appearance', 'apps', 'drivers', 'updates', 'metrics', 'notifications', 'profile', 'version', 'steamConnected', 'lastPlayed', 'lastCheck', 'updatesApplied'}
                        if not required <= data.keys(): raise ValueError()
                        data['mode'] = 'cli'
                    return data
                error = response['error']
                raise BackendError('CLI_REJECTED', str(error.get('message', 'Operation rejected'))[:300])
            except (ValueError, KeyError, TypeError, UnicodeError) as exc:
                raise BackendError('INVALID_RESPONSE', 'CLI did not return the documented JSON envelope') from exc
