"""Public API schema and fixed CLI argument mapping. No shell strings."""
import re

class BackendError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code

# Each operation has fixed tokens; only validated values are appended.
COMMANDS = {
    'snapshot': ('status', '--json'),
    'metrics': ('metrics', '--json'),
    'profile.set': ('performance', 'set', '--json'),
    'setting.set': ('settings', 'set', '--json'),
    'appearance.set': ('appearance', 'set', '--json'),
    'updates.check': ('updates', 'check', '--json'),
    'updates.apply': ('updates', 'apply', '--json'),
    'driver.install': ('drivers', 'install', '--json'),
    'app.toggle': ('apps', 'toggle', '--json'),
    'game.launch': ('games', 'launch', '--json'),
    'steam.connect': ('steam', 'connect', '--json'),
    'notifications.clear': ('notifications', 'clear', '--json'),
}
PROFILES = ('quiet', 'balanced', 'performance')
SETTINGS = ('wifi', 'bluetooth', 'notifications', 'gameMode', 'mangoHud', 'vrr', 'autoUpdates', 'doNotDisturb')
GAME_IDS = ('cyberpunk', 'elden-ring', 'hades', 'no-mans-sky', 'hollow-knight', 'forza')
APP_IDS = ('steam', 'lutris', 'heroic', 'discord', 'obs', 'bottles', 'firefox', 'vscode')

def validate(op, args):
    if op not in COMMANDS:
        raise BackendError('INVALID_OPERATION', 'Unknown operation')
    if not isinstance(args, dict):
        raise BackendError('INVALID_ARGUMENT', 'Arguments must be an object')
    expected = {
        'profile.set': {'profile'}, 'setting.set': {'key', 'value'},
        'appearance.set': {'key', 'value'}, 'driver.install': {'id'},
        'app.toggle': {'id'}, 'game.launch': {'id'},
    }.get(op, set())
    if set(args) != expected:
        raise BackendError('INVALID_ARGUMENT', 'Unexpected or missing arguments')
    valid = True
    if op == 'profile.set': valid = args['profile'] in PROFILES
    elif op == 'setting.set': valid = args['key'] in SETTINGS and type(args['value']) is bool
    elif op == 'appearance.set':
        allowed = {'accent': ('violet', 'cyan', 'blue'), 'wallpaper': ('aurora', 'grid', 'void'), 'scale': (90, 100, 110), 'reduceMotion': (True, False)}
        key, value = args['key'], args['value']
        valid = isinstance(key, str) and key in allowed and any(type(value) is type(x) and value == x for x in allowed.get(key, ()))
    elif op == 'driver.install': valid = args['id'] in ('nvidia', 'amd', 'controller')
    elif op == 'app.toggle': valid = args['id'] in APP_IDS
    elif op == 'game.launch': valid = args['id'] in GAME_IDS
    if not valid: raise BackendError('INVALID_ARGUMENT', 'Value is outside the allowed schema')
    return args

def argv_for(op, args):
    validate(op, args)
    result = list(COMMANDS[op])
    for key, value in args.items():
        result += ['--' + key, str(value).lower() if type(value) is bool else str(value)]
    return result
