import copy
import math
import threading
import time
from .contracts import validate, BackendError

class MockBackend:
    mode = 'mock'
    def __init__(self):
        self.lock = threading.RLock()
        self.tick = 0
        self.state = {
            'mode': 'mock', 'version': '0.9.0-preview', 'profile': 'balanced',
            'settings': {k: v for k, v in [('wifi', True), ('bluetooth', True), ('notifications', True), ('gameMode', True), ('mangoHud', False), ('vrr', True), ('autoUpdates', False), ('doNotDisturb', False)]},
            'appearance': {'accent': 'violet', 'wallpaper': 'aurora', 'scale': 100, 'reduceMotion': False},
            'system': {'hostname': 'spywonder-rig', 'cpu': 'AMD Ryzen 7 7800X3D', 'gpu': 'NVIDIA GeForce RTX 4070', 'memory': '32 GB DDR5', 'kernel': '6.11.8-spywonder', 'desktop': 'SpyWonder Shell 0.9', 'storageUsed': 428, 'storageTotal': 1000, 'uptime': '3h 42m', 'ip': '192.168.1.42', 'network': 'WonderNet · 5 GHz'},
            'steamConnected': False, 'lastPlayed': 'cyberpunk', 'lastCheck': 'Not checked this session', 'updatesApplied': False,
            'updates': [
                {'id': 'os', 'name': 'SpyWonder system image', 'version': '0.9.1-preview', 'size': '842 MB', 'type': 'System'},
                {'id': 'mesa', 'name': 'Mesa graphics stack', 'version': '24.2.6', 'size': '128 MB', 'type': 'Graphics'},
                {'id': 'steam-runtime', 'name': 'Steam Linux Runtime', 'version': '3.0.20241024', 'size': '96 MB', 'type': 'Gaming'}],
            'drivers': [
                {'id': 'nvidia', 'name': 'NVIDIA proprietary driver', 'version': '560.35.03', 'status': 'installed', 'description': 'GeForce RTX 4070 · Vulkan 1.3 · Wayland'},
                {'id': 'amd', 'name': 'AMD CPU microcode', 'version': '20241017', 'status': 'installed', 'description': 'Ryzen 7 7800X3D · security and stability'},
                {'id': 'controller', 'name': 'Xbox wireless controller support', 'version': 'xone 0.3', 'status': 'available', 'description': 'Optional · Xbox wireless adapter support'}],
            'apps': [
                {'id': 'steam', 'name': 'Steam', 'category': 'Gaming', 'description': 'Your games. All in one place.', 'installed': True, 'size': '1.2 GB', 'icon': 'gamepad'},
                {'id': 'lutris', 'name': 'Lutris', 'category': 'Gaming', 'description': 'An open gaming platform for Linux.', 'installed': True, 'size': '212 MB', 'icon': 'layers'},
                {'id': 'heroic', 'name': 'Heroic Games Launcher', 'category': 'Gaming', 'description': 'Epic, GOG and Amazon, together.', 'installed': False, 'size': '348 MB', 'icon': 'spark'},
                {'id': 'discord', 'name': 'Discord', 'category': 'Social', 'description': 'Find your people. Join the party.', 'installed': True, 'size': '286 MB', 'icon': 'chat'},
                {'id': 'obs', 'name': 'OBS Studio', 'category': 'Creative', 'description': 'Record and stream your best moments.', 'installed': False, 'size': '418 MB', 'icon': 'video'},
                {'id': 'bottles', 'name': 'Bottles', 'category': 'Utilities', 'description': 'Run Windows software with ease.', 'installed': False, 'size': '196 MB', 'icon': 'box'},
                {'id': 'firefox', 'name': 'Firefox', 'category': 'Internet', 'description': 'A browser that puts you first.', 'installed': True, 'size': '254 MB', 'icon': 'globe'},
                {'id': 'vscode', 'name': 'Visual Studio Code', 'category': 'Development', 'description': 'A home for your next idea.', 'installed': False, 'size': '362 MB', 'icon': 'code'}],
            'notifications': [{'title': 'Welcome to your next level', 'body': 'Your SpyWonder workspace is ready. Explore the Control Center.', 'time': 'Just now'}, {'title': '3 updates available', 'body': 'A fresh system image and gaming improvements await.', 'time': '12 min ago'}],
        }

    def metrics(self):
        self.tick += 1
        t = self.tick
        boost = 9 if self.state['profile'] == 'performance' else -6 if self.state['profile'] == 'quiet' else 0
        return {'cpu': round(22 + 8 * math.sin(t / 3) + boost), 'gpu': round(34 + 12 * math.sin(t / 5) + boost), 'ram': round(8.4 + .4 * math.sin(t / 7), 1), 'temp': round(48 + 4 * math.sin(t / 6) + boost / 2), 'power': round(94 + 12 * math.sin(t / 5) + boost), 'download': round(2.4 + math.sin(t / 4), 1)}

    def snapshot(self):
        result = copy.deepcopy(self.state)
        result['metrics'] = self.metrics()
        return result

    def request(self, op, args):
        validate(op, args)
        with self.lock:
            if op == 'metrics': return self.metrics()
            if op == 'profile.set': self.state['profile'] = args['profile']
            elif op == 'setting.set': self.state['settings'][args['key']] = args['value']
            elif op == 'appearance.set': self.state['appearance'][args['key']] = args['value']
            elif op == 'updates.check': self.state['lastCheck'] = time.strftime('%H:%M:%S')
            elif op == 'updates.apply':
                self.state['updates'] = []
                self.state['updatesApplied'] = True
                self.state['notifications'].insert(0, {'title': 'Demo update staged', 'body': 'Simulation complete. No files or packages were changed.', 'time': 'Just now'})
            elif op == 'driver.install':
                next(d for d in self.state['drivers'] if d['id'] == args['id'])['status'] = 'installed'
            elif op == 'app.toggle':
                app = next(a for a in self.state['apps'] if a['id'] == args['id'])
                app['installed'] = not app['installed']
            elif op == 'game.launch':
                self.state['lastPlayed'] = args['id']
                self.state['notifications'].insert(0, {'title': 'Game launch simulated', 'body': 'Launch request accepted by the mock backend. No process was started.', 'time': 'Just now'})
            elif op == 'steam.connect': self.state['steamConnected'] = not self.state['steamConnected']
            elif op == 'notifications.clear': self.state['notifications'] = []
            return self.snapshot()
