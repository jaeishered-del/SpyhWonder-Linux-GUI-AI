import json
from .contracts import BackendError
from .mock import MockBackend
from .cli import CLIBackend

def create_backend(config=None):
    return CLIBackend(config) if config else MockBackend()

def handle(backend, request):
    try:
        if not isinstance(request, dict) or set(request) != {'op', 'args'}:
            raise BackendError('INVALID_REQUEST', 'Expected op and args')
        return {'ok': True, 'data': backend.request(request['op'], request['args'])}
    except BackendError as exc:
        return {'ok': False, 'error': {'code': exc.code, 'message': str(exc)}}
    except Exception:
        return {'ok': False, 'error': {'code': 'INTERNAL', 'message': 'Backend request failed safely'}}
